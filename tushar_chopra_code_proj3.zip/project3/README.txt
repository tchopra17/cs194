Run notebook for results

